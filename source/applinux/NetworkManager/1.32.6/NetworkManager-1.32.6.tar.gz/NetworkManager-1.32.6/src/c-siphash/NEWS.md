# c-siphash - Streaming-capable SipHash Implementation

## CHANGES WITH 1:

        * Initial release of c-siphash.

        * TBD

        Contributions from: TBD

        - TBD, YYYY-MM-DD
