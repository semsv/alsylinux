# c-stdaux - Auxiliary macros and functions for the C standard library

## CHANGES WITH 1:

        * Initial release of c-stdaux.

        * TBD

        Contributions from: TBD

        - TBD, YYYY-MM-DD
